"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/authors";
exports.ids = ["pages/api/authors"];
exports.modules = {

/***/ "next/dist/compiled/next-server/pages-api.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages-api.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages-api.runtime.dev.js");

/***/ }),

/***/ "(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fauthors&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Cauthors.js&middlewareConfigBase64=e30%3D!":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fauthors&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Cauthors.js&middlewareConfigBase64=e30%3D! ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   routeModule: () => (/* binding */ routeModule)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages-api/module.compiled */ \"(api)/./node_modules/next/dist/server/future/route-modules/pages-api/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(api)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"(api)/./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var _pages_api_authors_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages\\api\\authors.js */ \"(api)/./pages/api/authors.js\");\n\n\n\n// Import the userland code.\n\n// Re-export the handler (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_authors_js__WEBPACK_IMPORTED_MODULE_3__, \"default\"));\n// Re-export config.\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_authors_js__WEBPACK_IMPORTED_MODULE_3__, \"config\");\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesAPIRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES_API,\n        page: \"/api/authors\",\n        pathname: \"/api/authors\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    userland: _pages_api_authors_js__WEBPACK_IMPORTED_MODULE_3__\n});\n\n//# sourceMappingURL=pages-api.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTX0FQSSZwYWdlPSUyRmFwaSUyRmF1dGhvcnMmcHJlZmVycmVkUmVnaW9uPSZhYnNvbHV0ZVBhZ2VQYXRoPS4lMkZwYWdlcyU1Q2FwaSU1Q2F1dGhvcnMuanMmbWlkZGxld2FyZUNvbmZpZ0Jhc2U2ND1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQXNHO0FBQ3ZDO0FBQ0w7QUFDMUQ7QUFDcUQ7QUFDckQ7QUFDQSxpRUFBZSx3RUFBSyxDQUFDLGtEQUFRLFlBQVksRUFBQztBQUMxQztBQUNPLGVBQWUsd0VBQUssQ0FBQyxrREFBUTtBQUNwQztBQUNPLHdCQUF3QixnSEFBbUI7QUFDbEQ7QUFDQSxjQUFjLHlFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsWUFBWTtBQUNaLENBQUM7O0FBRUQiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hc3MyLz9jZGNhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBhZ2VzQVBJUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUtbW9kdWxlcy9wYWdlcy1hcGkvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUta2luZFwiO1xuaW1wb3J0IHsgaG9pc3QgfSBmcm9tIFwibmV4dC9kaXN0L2J1aWxkL3RlbXBsYXRlcy9oZWxwZXJzXCI7XG4vLyBJbXBvcnQgdGhlIHVzZXJsYW5kIGNvZGUuXG5pbXBvcnQgKiBhcyB1c2VybGFuZCBmcm9tIFwiLi9wYWdlc1xcXFxhcGlcXFxcYXV0aG9ycy5qc1wiO1xuLy8gUmUtZXhwb3J0IHRoZSBoYW5kbGVyIChzaG91bGQgYmUgdGhlIGRlZmF1bHQgZXhwb3J0KS5cbmV4cG9ydCBkZWZhdWx0IGhvaXN0KHVzZXJsYW5kLCBcImRlZmF1bHRcIik7XG4vLyBSZS1leHBvcnQgY29uZmlnLlxuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IGhvaXN0KHVzZXJsYW5kLCBcImNvbmZpZ1wiKTtcbi8vIENyZWF0ZSBhbmQgZXhwb3J0IHRoZSByb3V0ZSBtb2R1bGUgdGhhdCB3aWxsIGJlIGNvbnN1bWVkLlxuZXhwb3J0IGNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IFBhZ2VzQVBJUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLlBBR0VTX0FQSSxcbiAgICAgICAgcGFnZTogXCIvYXBpL2F1dGhvcnNcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS9hdXRob3JzXCIsXG4gICAgICAgIC8vIFRoZSBmb2xsb3dpbmcgYXJlbid0IHVzZWQgaW4gcHJvZHVjdGlvbi5cbiAgICAgICAgYnVuZGxlUGF0aDogXCJcIixcbiAgICAgICAgZmlsZW5hbWU6IFwiXCJcbiAgICB9LFxuICAgIHVzZXJsYW5kXG59KTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFnZXMtYXBpLmpzLm1hcCJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fauthors&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Cauthors.js&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "(api)/./pages/api/authors.js":
/*!******************************!*\
  !*** ./pages/api/authors.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _Data_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../Data.json */ \"(api)/./Data.json\");\n// pages/api/authors.js\n\nfunction handler(req, res) {\n    res.status(200).json(_Data_json__WEBPACK_IMPORTED_MODULE_0__.authors);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvYXV0aG9ycy5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFBLHVCQUF1QjtBQUNXO0FBRW5CLFNBQVNDLFFBQVFDLEdBQUcsRUFBRUMsR0FBRztJQUN0Q0EsSUFBSUMsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQ0wsK0NBQVk7QUFDbkMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hc3MyLy4vcGFnZXMvYXBpL2F1dGhvcnMuanM/Y2M3NyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBwYWdlcy9hcGkvYXV0aG9ycy5qc1xyXG5pbXBvcnQgZGF0YSBmcm9tICcuLi8uLi9EYXRhLmpzb24nXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBoYW5kbGVyKHJlcSwgcmVzKSB7XHJcbiAgcmVzLnN0YXR1cygyMDApLmpzb24oZGF0YS5hdXRob3JzKVxyXG59Il0sIm5hbWVzIjpbImRhdGEiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwic3RhdHVzIiwianNvbiIsImF1dGhvcnMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/authors.js\n");

/***/ }),

/***/ "(api)/./Data.json":
/*!*******************!*\
  !*** ./Data.json ***!
  \*******************/
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"books":[{"id":"1","title":"The Great Gatsby","authorId":"1","description":"A novel about the American dream and the disillusionment that comes with it.","price":10.99,"genreId":"1","rating":4.4},{"id":"2","title":"To Kill a Mockingbird","authorId":"2","description":"A novel set in the Deep South and focused on themes of racial injustice and moral growth.","price":12.99,"genreId":"1","rating":4.8},{"id":"3","title":"1984","authorId":"3","description":"A dystopian novel that explores the dangers of totalitarianism and extreme political ideology.","price":14.99,"genreId":"2","rating":4.7},{"id":"4","title":"Pride and Prejudice","authorId":"4","description":"A romantic novel that charts the emotional development of the protagonist, Elizabeth Bennet.","price":9.99,"genreId":"3","rating":4.6},{"id":"5","title":"The Catcher in the Rye","authorId":"5","description":"A story about teenage rebellion and alienation narrated by the protagonist Holden Caulfield.","price":11.99,"genreId":"1","rating":4},{"id":"6","title":"The Alchemist","authorId":"6","description":"A philosophical book that tells the story of Santiago, a shepherd boy on a journey to discover his personal legend.","price":13.99,"genreId":"4","rating":4.5}],"genres":[{"id":"1","name":"Fiction"},{"id":"2","name":"Dystopian"},{"id":"3","name":"Romance"},{"id":"4","name":"Adventure"}],"authors":[{"id":"1","name":"F. Scott Fitzgerald","biography":"An American novelist and short story writer."},{"id":"2","name":"Harper Lee","biography":"An American novelist known for \'To Kill a Mockingbird\'."},{"id":"3","name":"George Orwell","biography":"An English novelist and essayist."},{"id":"4","name":"Jane Austen","biography":"An English novelist known for her social commentary."},{"id":"5","name":"J.D. Salinger","biography":"An American writer known for \'The Catcher in the Rye\'."},{"id":"6","name":"Paulo Coelho","biography":"A Brazilian lyricist and novelist."}],"reviews":[{"id":"1","bookId":"1","userId":"101","rating":5,"comment":"A timeless classic!"},{"id":"2","bookId":"2","userId":"102","rating":4,"comment":"A powerful story."},{"id":"3","bookId":"3","userId":"103","rating":5,"comment":"Chilling and thought-provoking."},{"id":"4","bookId":"4","userId":"104","rating":4,"comment":"A beautifully written love story."}],"users":[{"id":"101","username":"reader1","email":"reader1@example.com"},{"id":"102","username":"reader2","email":"reader2@example.com"},{"id":"103","username":"reader3","email":"reader3@example.com"},{"id":"104","username":"reader4","email":"reader4@example.com"}]}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next"], () => (__webpack_exec__("(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fauthors&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Cauthors.js&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();